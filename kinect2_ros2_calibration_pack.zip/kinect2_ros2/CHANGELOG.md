# Changelog

All notable changes to this fork will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Unreleased]

### Planned
- CUDA depth registration support
- CUDA depth processing support
- OpenCL acceleration
- Performance monitoring tools
- Multi-Kinect support

## [1.0.0] - 2025-11-20

### Fixed

#### CPU Registration Not Available
**Problem**: Bridge failed with "CPU registration is not available!" error.

**Root Cause**: kinect2_bridge CMakeLists.txt was missing Eigen3 detection and DEPTH_REG_CPU definition, even though kinect2_registration had it.

**Solution**: Added to `kinect2_bridge/CMakeLists.txt`:
```cmake
find_package(eigen3_cmake_module REQUIRED)
find_package(Eigen3)

if(EIGEN3_FOUND)
  message(STATUS "CPU based depth registration enabled")
  include_directories(${EIGEN3_INCLUDE_DIR})
  add_definitions(-DDEPTH_REG_CPU)
endif()
```

**Impact**: CPU registration now works, bridge can process depth data.

#### Library Linking Errors
**Problem**: Linker failed with "cannot find -lfreenect2" error.

**Root Cause**: CMakeLists.txt wasn't setting up library directories and was using wrong variable for linking.

**Solution**: Changed in `kinect2_bridge/CMakeLists.txt`:
```cmake
# Before:
target_link_libraries(${PROJECT_NAME}_node freenect2)

# After:
link_directories(${freenect2_LIBRARY_DIRS})
target_link_libraries(${PROJECT_NAME}_node ${freenect2_LIBRARIES})
include_directories(${freenect2_INCLUDE_DIRS})
```

**Impact**: Bridge now links properly with libfreenect2.

#### GLX BadAccess Error
**Problem**: Bridge crashed with "X Error: BadAccess (GLX)" on some systems.

**Root Cause**: Default depth_method "default" tries OpenGL first, which conflicts with some GPU configurations.

**Solution**: Changed in `kinect2_bridge/launch/kinect2_bridge_launch.yaml`:
```yaml
depth_method: cpu  # was: default
reg_method: cpu    # was: default
```

**Impact**: Bridge works on all systems, no OpenGL conflicts.

### Added
- Comprehensive README.md with fixes documented
- QUICKSTART.md for fast setup
- BUILD_GUIDE.md with detailed instructions
- This CHANGELOG.md

### Tested
- ✅ ROS2 Jazzy Jalopy on Ubuntu 24.04
- ✅ Kinect v2 (Xbox One) sensor serial 003943241347
- ✅ CPU registration at ~15Hz depth, ~30Hz color
- ✅ RTAB-Map SLAM integration
- ✅ RViz2 visualization
- ✅ Point cloud generation

## Upstream Compatibility

This fork maintains compatibility with krepa098/kinect2_ros2:
- Same package structure
- Same topic names
- Same launch file format
- Same calibration file format

**Migration**: Just replace the package and rebuild. No code changes needed.

## Performance Metrics

### Before (Original - Broken)
- CPU registration: ❌ Not working
- Bridge: ❌ Failed to initialize
- Publishing: ❌ N/A

### After (This Fork - Working)
- CPU registration: ✅ Working
- Depth processing: ~0.45ms (~2200Hz internal)
- Publishing rate: ~15Hz depth, ~30Hz color
- Latency: ~20-30ms
- CPU usage: Moderate (4 worker threads)

## Known Issues

### Fixed in This Version
- ✅ CPU registration not available
- ✅ GLX BadAccess error
- ✅ Library linking errors
- ✅ Missing DEPTH_REG_CPU definition

### Still Present (From Upstream)
- ⚠️ CUDA support disabled (working on enabling it)
- ⚠️ OpenCL support disabled
- ⚠️ Factory calibration warnings (need custom calibration)
- ⚠️ No kinect2_viewer (use RViz2 instead)

## Breaking Changes

None. This fork is backward compatible with the original kinect2_ros2.

## Migration Guide

### From krepa098/kinect2_ros2

1. **Replace package**:
   ```bash
   cd ~/ros2_ws/src
   mv kinect2_ros2 kinect2_ros2_original
   git clone https://github.com/AryanRai/kinect2_ros2_cuda.git kinect2_ros2
   ```

2. **Rebuild**:
   ```bash
   cd ~/ros2_ws
   rm -rf build/ install/
   colcon build --packages-select kinect2_registration kinect2_bridge
   ```

3. **No code changes needed** - launch files and calibrations work as-is.

### From Original iai_kinect2 (ROS1)

Not directly compatible. This is a ROS2 package. See krepa098/kinect2_ros2 for ROS1 to ROS2 migration guide.

## Credits

### This Version (1.0.0)
- AryanRai - Bug fixes, documentation, CUDA preparation

### Upstream
- krepa098 - ROS2 port
- Thiemo Wiedemeyer - Original iai_kinect2

## Links

- **This Fork**: https://github.com/AryanRai/kinect2_ros2_cuda
- **Upstream**: https://github.com/krepa098/kinect2_ros2  
- **Original**: https://github.com/code-iai/iai_kinect2
- **Issues**: https://github.com/AryanRai/kinect2_ros2_cuda/issues
