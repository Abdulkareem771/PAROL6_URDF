/**
 * Copyright 2014 University of Bremen, Institute for Artificial Intelligence
 * Author: Thiemo Wiedemeyer <wiedemeyer@cs.uni-bremen.de>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdlib.h>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>

#include <CL/opencl.hpp>
#include <algorithm>

#include "depth_registration_opencl.h"

#define REG_OPENCL_FILE "/opt/kinect_ws/src/kinect2_ros2/kinect2_registration/src/depth_registration.cl"

#define CHECK_CL_RETURN(node, call) do { \
  cl_int err = call; \
  if (err != CL_SUCCESS) { \
    RCLCPP_ERROR(node->get_logger(), "OpenCL error %d at %s:%d", err, __FILE__, __LINE__); \
    return false; \
  } \
} while(0)

#define CHECK_CL_PARAM(node, call) do { \
  call; \
  if (err != CL_SUCCESS) { \
    RCLCPP_ERROR(node->get_logger(), "OpenCL error %d at %s:%d", err, __FILE__, __LINE__); \
    return false; \
  } \
} while(0)

struct DepthRegistrationOpenCL::OCLData
{
  cl::Context context;
  cl::Device device;
  cl::CommandQueue queue;
  cl::Program program;
  cl::Kernel kernelSetZero, kernelProject, kernelCheckDepth, kernelRemap;

  cl::Buffer bufferDepth, bufferScaled, bufferRegistered, bufferIndex, bufferImgZ, bufferDists, bufferSelDist, bufferMapX, bufferMapY, bufferOutput;

  size_t sizeDepth, sizeRegistered, sizeIndex, sizeImgZ, sizeDists, sizeSelDist, sizeMap;

  unsigned char *dataOutput;
  
  #ifdef ENABLE_PROFILING_CL
  std::vector<double> timings;
  int count;
  #endif
};

DepthRegistrationOpenCL::DepthRegistrationOpenCL(rclcpp::Node::SharedPtr node)
  : node(node), fillHoles(false), holeFillRadius(0)
{
  data = new OCLData();
  
  #ifdef ENABLE_PROFILING_CL
  data->count = 0;
  #endif
}

DepthRegistrationOpenCL::~DepthRegistrationOpenCL()
{
  delete data;
}

void DepthRegistrationOpenCL::setHoleFilling(bool enable, int radius)
{
  fillHoles = enable;
  holeFillRadius = std::max(1, std::min(radius, 10));
}

bool DepthRegistrationOpenCL::init(const int deviceId)
{
  std::vector<cl::Platform> platforms;
  cl::Platform::get(&platforms);

  if (platforms.empty())
  {
    RCLCPP_ERROR(node->get_logger(), "No OpenCL platforms found.");
    return false;
  }

  cl::Platform platform = platforms[0];
  std::vector<cl::Device> devices;
  platform.getDevices(CL_DEVICE_TYPE_GPU, &devices);

  if (devices.empty())
  {
    RCLCPP_ERROR(node->get_logger(), "No OpenCL devices found.");
    return false;
  }

  if (deviceId >= (int)devices.size())
  {
    RCLCPP_ERROR(node->get_logger(), "Invalid device ID.");
    return false;
  }

  data->device = devices[deviceId < 0 ? 0 : deviceId];
  
  cl_int err;
  data->context = cl::Context(data->device, NULL, NULL, NULL, &err);
  CHECK_CL_PARAM(node, (void)0);

#ifdef ENABLE_PROFILING_CL
  data->queue = cl::CommandQueue(data->context, data->device, CL_QUEUE_PROFILING_ENABLE, &err);
#else
  data->queue = cl::CommandQueue(data->context, data->device, 0, &err);
#endif
  CHECK_CL_PARAM(node, (void)0);

  std::string source;
  if (!readProgram(source))
  {
    RCLCPP_ERROR(node->get_logger(), "Could not read OpenCL program.");
    return false;
  }

  std::string options;
  generateOptions(options);

  cl::Program::Sources sources(1, source);
  data->program = cl::Program(data->context, sources);
  
  err = data->program.build(std::vector<cl::Device>({data->device}), options.c_str());
  if (err != CL_SUCCESS)
  {
    RCLCPP_ERROR(node->get_logger(), "OpenCL build error: %d", err);
    RCLCPP_ERROR(node->get_logger(), "Build log: %s", data->program.getBuildInfo<CL_PROGRAM_BUILD_LOG>(data->device).c_str());
    return false;
  }

  data->sizeDepth = sizeDepth.width * sizeDepth.height * sizeof(uint16_t);
  data->sizeRegistered = sizeRegistered.width * sizeRegistered.height * sizeof(uint16_t);
  data->sizeIndex = sizeRegistered.width * sizeRegistered.height * sizeof(int);
  data->sizeImgZ = sizeRegistered.width * sizeRegistered.height * sizeof(uint16_t);
  data->sizeDists = sizeRegistered.width * sizeRegistered.height * sizeof(float);
  data->sizeSelDist = sizeRegistered.width * sizeRegistered.height * sizeof(float);
  data->sizeMap = sizeRegistered.width * sizeRegistered.height * sizeof(float);

  CHECK_CL_PARAM(node, data->bufferDepth = cl::Buffer(data->context, CL_MEM_READ_ONLY, data->sizeDepth, NULL, &err));
  CHECK_CL_PARAM(node, data->bufferScaled = cl::Buffer(data->context, CL_MEM_READ_WRITE, data->sizeDepth, NULL, &err));
  CHECK_CL_PARAM(node, data->bufferRegistered = cl::Buffer(data->context, CL_MEM_READ_WRITE, data->sizeRegistered, NULL, &err));
  CHECK_CL_PARAM(node, data->bufferIndex = cl::Buffer(data->context, CL_MEM_READ_WRITE, data->sizeIndex, NULL, &err));
  CHECK_CL_PARAM(node, data->bufferImgZ = cl::Buffer(data->context, CL_MEM_READ_WRITE, data->sizeImgZ, NULL, &err));
  CHECK_CL_PARAM(node, data->bufferDists = cl::Buffer(data->context, CL_MEM_READ_WRITE, data->sizeDists, NULL, &err));
  CHECK_CL_PARAM(node, data->bufferSelDist = cl::Buffer(data->context, CL_MEM_READ_WRITE, data->sizeSelDist, NULL, &err));
  CHECK_CL_PARAM(node, data->bufferMapX = cl::Buffer(data->context, CL_MEM_READ_ONLY, data->sizeMap, NULL, &err));
  CHECK_CL_PARAM(node, data->bufferMapY = cl::Buffer(data->context, CL_MEM_READ_ONLY, data->sizeMap, NULL, &err));
  CHECK_CL_PARAM(node, data->bufferOutput = cl::Buffer(data->context, CL_MEM_WRITE_ONLY | CL_MEM_ALLOC_HOST_PTR, data->sizeRegistered, NULL, &err));

  CHECK_CL_PARAM(node, data->kernelSetZero = cl::Kernel(data->program, "setZero", &err));
  CHECK_CL_RETURN(node, data->kernelSetZero.setArg(0, data->bufferRegistered));
  CHECK_CL_RETURN(node, data->kernelSetZero.setArg(1, data->bufferSelDist));

  CHECK_CL_PARAM(node, data->kernelProject = cl::Kernel(data->program, "project", &err));
  CHECK_CL_RETURN(node, data->kernelProject.setArg(0, data->bufferScaled));
  CHECK_CL_RETURN(node, data->kernelProject.setArg(1, data->bufferIndex));
  CHECK_CL_RETURN(node, data->kernelProject.setArg(2, data->bufferImgZ));
  CHECK_CL_RETURN(node, data->kernelProject.setArg(3, data->bufferDists));
  CHECK_CL_RETURN(node, data->kernelProject.setArg(4, data->bufferSelDist));
  CHECK_CL_RETURN(node, data->kernelProject.setArg(5, data->bufferRegistered));

  CHECK_CL_PARAM(node, data->kernelCheckDepth = cl::Kernel(data->program, "checkDepth", &err));
  CHECK_CL_RETURN(node, data->kernelCheckDepth.setArg(0, data->bufferIndex));
  CHECK_CL_RETURN(node, data->kernelCheckDepth.setArg(1, data->bufferImgZ));
  CHECK_CL_RETURN(node, data->kernelCheckDepth.setArg(2, data->bufferDists));
  CHECK_CL_RETURN(node, data->kernelCheckDepth.setArg(3, data->bufferSelDist));
  CHECK_CL_RETURN(node, data->kernelCheckDepth.setArg(4, data->bufferRegistered));

  CHECK_CL_PARAM(node, data->kernelRemap = cl::Kernel(data->program, "remapDepth", &err));
  CHECK_CL_RETURN(node, data->kernelRemap.setArg(0, data->bufferDepth));
  CHECK_CL_RETURN(node, data->kernelRemap.setArg(1, data->bufferScaled));
  CHECK_CL_RETURN(node, data->kernelRemap.setArg(2, data->bufferMapX));
  CHECK_CL_RETURN(node, data->kernelRemap.setArg(3, data->bufferMapY));

  CHECK_CL_RETURN(node, data->queue.enqueueWriteBuffer(data->bufferMapX, CL_TRUE, 0, data->sizeMap, mapX.data));
  CHECK_CL_RETURN(node, data->queue.enqueueWriteBuffer(data->bufferMapY, CL_TRUE, 0, data->sizeMap, mapY.data));

  CHECK_CL_PARAM(node, data->dataOutput = (unsigned char *)data->queue.enqueueMapBuffer(data->bufferOutput, CL_TRUE, CL_MAP_READ, 0, data->sizeRegistered, NULL, NULL, &err));
  return true;
}

bool DepthRegistrationOpenCL::registerDepth(const cv::Mat &depth, cv::Mat &registered)
{
  cl::Event eventRead;
  std::vector<cl::Event> eventZero(2), eventRemap(1), eventProject(1), eventCheckDepth1(1), eventCheckDepth2(1);
  cl::NDRange range(sizeRegistered.height * sizeRegistered.width);

  CHECK_CL_RETURN(node, data->queue.enqueueWriteBuffer(data->bufferDepth, CL_FALSE, 0, data->sizeDepth, depth.data, NULL, &eventZero[0]));
  CHECK_CL_RETURN(node, data->queue.enqueueNDRangeKernel(data->kernelSetZero, cl::NullRange, range, cl::NullRange, NULL, &eventZero[1]));

  CHECK_CL_RETURN(node, data->queue.enqueueNDRangeKernel(data->kernelRemap, cl::NullRange, range, cl::NullRange, &eventZero, &eventRemap[0]));

  CHECK_CL_RETURN(node, data->queue.enqueueNDRangeKernel(data->kernelProject, cl::NullRange, range, cl::NullRange, &eventRemap, &eventProject[0]));

  CHECK_CL_RETURN(node, data->queue.enqueueNDRangeKernel(data->kernelCheckDepth, cl::NullRange, range, cl::NullRange, &eventProject, &eventCheckDepth1[0]));

  CHECK_CL_RETURN(node, data->queue.enqueueNDRangeKernel(data->kernelCheckDepth, cl::NullRange, range, cl::NullRange, &eventCheckDepth1, &eventCheckDepth2[0]));

  CHECK_CL_RETURN(node, data->queue.enqueueReadBuffer(data->bufferRegistered, CL_FALSE, 0, data->sizeRegistered, data->dataOutput, &eventCheckDepth2, &eventRead));

  CHECK_CL_RETURN(node, eventRead.wait());

  registered = cv::Mat(sizeRegistered, CV_16U, data->dataOutput);

  if (fillHoles && holeFillRadius > 0)
  {
    cv::Mat mask = (registered == 0);
    if (cv::countNonZero(mask) > 0)
    {
      cv::inpaint(registered, mask, registered, holeFillRadius, cv::INPAINT_TELEA);
    }
  }

#ifdef ENABLE_PROFILING_CL
  if (data->count == 0)
  {
    data->timings.clear();
    data->timings.resize(7, 0.0);
  }

  data->timings[0] += eventZero[0].getProfilingInfo<CL_PROFILING_COMMAND_END>() - eventZero[0].getProfilingInfo<CL_PROFILING_COMMAND_START>();
  data->timings[1] += eventZero[1].getProfilingInfo<CL_PROFILING_COMMAND_END>() - eventZero[1].getProfilingInfo<CL_PROFILING_COMMAND_START>();
  data->timings[2] += eventRemap[0].getProfilingInfo<CL_PROFILING_COMMAND_END>() - eventRemap[0].getProfilingInfo<CL_PROFILING_COMMAND_START>();
  data->timings[3] += eventProject[0].getProfilingInfo<CL_PROFILING_COMMAND_END>() - eventProject[0].getProfilingInfo<CL_PROFILING_COMMAND_START>();
  data->timings[4] += eventCheckDepth1[0].getProfilingInfo<CL_PROFILING_COMMAND_END>() - eventCheckDepth1[0].getProfilingInfo<CL_PROFILING_COMMAND_START>();
  data->timings[5] += eventCheckDepth2[0].getProfilingInfo<CL_PROFILING_COMMAND_END>() - eventCheckDepth2[0].getProfilingInfo<CL_PROFILING_COMMAND_START>();
  data->timings[6] += eventRead.getProfilingInfo<CL_PROFILING_COMMAND_END>() - eventRead.getProfilingInfo<CL_PROFILING_COMMAND_START>();

  if (++data->count == 100)
  {
    double sum = data->timings[0] + data->timings[1] + data->timings[2] + data->timings[3] + data->timings[4] + data->timings[5] + data->timings[6];
    OUT_INFO("writing depth: " << data->timings[0] / 100000000.0 << " ms.");
    OUT_INFO("setting zero: " << data->timings[1] / 100000000.0 << " ms.");
    OUT_INFO("remap: " << data->timings[2] / 100000000.0 << " ms.");
    OUT_INFO("project: " << data->timings[3] / 100000000.0 << " ms.");
    OUT_INFO("check depth 1: " << data->timings[4] / 100000000.0 << " ms.");
    OUT_INFO("check depth 2: " << data->timings[5] / 100000000.0 << " ms.");
    OUT_INFO("read registered: " << data->timings[6] / 100000000.0 << " ms.");
    OUT_INFO("overall: " << sum / 100000000.0 << " ms.");
    data->count = 0;
  }
#endif
  return true;
}

void DepthRegistrationOpenCL::generateOptions(std::string &options) const
{
  std::ostringstream oss;
  oss.precision(16);
  oss << std::scientific;

  // Rotation
  oss << " -D r00=" << rotation.at<double>(0, 0) << "f";
  oss << " -D r01=" << rotation.at<double>(0, 1) << "f";
  oss << " -D r02=" << rotation.at<double>(0, 2) << "f";
  oss << " -D r10=" << rotation.at<double>(1, 0) << "f";
  oss << " -D r11=" << rotation.at<double>(1, 1) << "f";
  oss << " -D r12=" << rotation.at<double>(1, 2) << "f";
  oss << " -D r20=" << rotation.at<double>(2, 0) << "f";
  oss << " -D r21=" << rotation.at<double>(2, 1) << "f";
  oss << " -D r22=" << rotation.at<double>(2, 2) << "f";

  // Translation
  oss << " -D tx=" << translation.at<double>(0, 0) << "f";
  oss << " -D ty=" << translation.at<double>(1, 0) << "f";
  oss << " -D tz=" << translation.at<double>(2, 0) << "f";

  // Camera parameter upscaled depth
  oss << " -D fxR=" << cameraMatrixRegistered.at<double>(0, 0) << "f";
  oss << " -D fyR=" << cameraMatrixRegistered.at<double>(1, 1) << "f";
  oss << " -D cxR=" << cameraMatrixRegistered.at<double>(0, 2) << "f";
  oss << " -D cyR=" << cameraMatrixRegistered.at<double>(1, 2) << "f";
  oss << " -D fxRInv=" << (1.0 / cameraMatrixRegistered.at<double>(0, 0)) << "f";
  oss << " -D fyRInv=" << (1.0 / cameraMatrixRegistered.at<double>(1, 1)) << "f";

  // Clipping distances
  oss << " -D zNear=" << (uint16_t)(zNear * 1000);
  oss << " -D zFar=" << (uint16_t)(zFar * 1000);

  // Size registered image
  oss << " -D heightR=" << sizeRegistered.height;
  oss << " -D widthR=" << sizeRegistered.width;

  // Size depth image
  oss << " -D heightD=" << sizeDepth.height;
  oss << " -D widthD=" << sizeDepth.width;

  options = oss.str();
}

bool DepthRegistrationOpenCL::readProgram(std::string &source) const
{
  std::ifstream file(REG_OPENCL_FILE);

  if (!file.is_open())
  {
    return false;
  }

  source = std::string((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
  file.close();

  return true;
}
